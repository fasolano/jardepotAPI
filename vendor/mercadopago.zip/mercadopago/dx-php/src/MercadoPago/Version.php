<?php
namespace MercadoPago;

class Version
{
    public static
        $_VERSION = '1.5.0';
}